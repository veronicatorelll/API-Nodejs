module.exports = [
    { 
        id: 1,
        make: "Volvo",
        model: "740",
    },
    { 
        id: 2,
        make: "Saab",
        model: "9000",
    },
    { 
        id: 3,
        make: "Mercedes",
        model: "S30",
    },
    { 
        id: 4,
        make: "Toyota",
        model: "T40",
    },
    { 
        id: 5,
        make: "Chevrolet",
        model: "X91",
    },
    { 
        id: 6,
        make: "BMW",
        model: "750",
    },
]