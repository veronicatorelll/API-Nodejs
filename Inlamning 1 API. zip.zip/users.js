module.exports = [
    {
        id: 1,
        name: "Linus",
        username: "LinusR",
        description: "Lärare",
        mail: "linus@live.se",
        password: "linuspw"
    },
    {
        id: 2,
        name: "Anna",
        username: "AnnaR",
        description: "Linus syster",
        mail: "anna@live.se",
        password: "annaspw"
    },
    {
        id: 3,
        name: "Veronica",
        username: "VeronicaT",
        description: "Student",
        mail: "veronica@live.se",
        password: "veronicaspw"
    }
]